#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 * @Author: Jesse Y
 * @Date: ${YEAR}-${MONTH}-${DAY} ${TIME}
 */
public interface ${NAME} {
}
